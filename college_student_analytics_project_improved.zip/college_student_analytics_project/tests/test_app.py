import io

import pytest

import app as app_module
import seed_data
from conftest import csrf_from


# ---------------------------------------------------------------- data generation
def test_seed_generation_is_deterministic_and_valid():
    first = seed_data.generate_dataset(60)
    assert first == seed_data.generate_dataset(60)
    students, attendance, exams, placements = first
    assert len(students) == 60 and len(attendance) == 240 and len(exams) == 240
    assert all(0 <= a["attendance_percentage"] <= 100 for a in attendance)
    assert all((e["result"] == "Pass") == (e["marks_obtained"] >= 40) for e in exams)
    eligible_ids = {s["student_id"] for s in students if s["placement_eligible"]}
    assert {p["student_id"] for p in placements} == eligible_ids


# ---------------------------------------------------------------- authentication / CSRF
def test_pages_require_login(client):
    for path in ("/dashboard", "/students", "/academics", "/attendance", "/placements", "/data-tools"):
        assert client.get(path).status_code == 302


def test_login_success_and_failure(client, login):
    assert login("admin", "wrong").status_code == 200  # re-renders the form with a flash message
    resp = login("admin", "Admin@1234")
    assert resp.status_code == 302 and resp.headers["Location"].endswith("/dashboard")


def test_post_without_csrf_token_is_rejected(client):
    assert client.post("/login", data={"username": "admin", "password": "Admin@1234"}).status_code == 400


def test_login_lockout_after_repeated_failures(client, login):
    for _ in range(app_module.MAX_LOGIN_FAILURES):
        login("admin", "wrong")
    assert login("admin", "Admin@1234").status_code == 429


def test_open_redirect_is_blocked(client):
    token = csrf_from(client)
    resp = client.post("/login?next=//evil.example", data={"username": "admin", "password": "Admin@1234", "_csrf": token})
    assert resp.headers["Location"].endswith("/dashboard")


def test_security_headers_present(client):
    resp = client.get("/login")
    assert resp.headers["X-Frame-Options"] == "DENY"
    assert "default-src 'self'" in resp.headers["Content-Security-Policy"]


# ---------------------------------------------------------------- role-based access
@pytest.mark.parametrize("user,password,allowed,denied", [
    ("admin", "Admin@1234", ["/dashboard", "/students", "/academics", "/attendance", "/placements", "/data-tools"], []),
    ("faculty", "Faculty@1234", ["/dashboard", "/students", "/academics", "/attendance"], ["/placements", "/data-tools"]),
    ("placement", "Placement@1234", ["/dashboard", "/students", "/placements"], ["/academics", "/attendance", "/data-tools"]),
])
def test_role_access(client, login, user, password, allowed, denied):
    login(user, password)
    for path in allowed:
        assert client.get(path).status_code == 200, path
    for path in denied:
        assert client.get(path).status_code == 302, path


def test_export_permissions(client, login):
    login("placement", "Placement@1234")
    assert client.get("/export/placements.csv").status_code == 200
    assert client.get("/export/examinations.csv").status_code == 403
    assert client.get("/export/unknown.csv").status_code == 404


# ---------------------------------------------------------------- analytics
def test_dashboard_numbers_match_database(client, login, database):
    login("admin", "Admin@1234")
    body = client.get("/dashboard").get_data(as_text=True)
    assert str(database.students.count_documents({})) in body


def test_academic_summary_matches_manual_calculation(database):
    rows = {r["department"]: r for r in app_module.department_academic_summary()}
    dept = next(iter(rows))
    docs = list(database.examinations.find({"department": dept}))
    expected_avg = round(sum(d["percentage"] for d in docs) / len(docs), 1)
    expected_pass = round(sum(d["result"] == "Pass" for d in docs) / len(docs) * 100, 1)
    assert rows[dept]["average_score"] == pytest.approx(expected_avg, abs=0.11)
    assert rows[dept]["pass_rate"] == pytest.approx(expected_pass, abs=0.11)
    assert rows[dept]["records"] == len(docs)


def test_placement_rate_uses_eligible_students(database):
    for row in app_module.department_placement_summary():
        eligible = database.students.count_documents({"department": row["department"], "placement_eligible": True})
        assert row["eligible"] == eligible
        assert row["placement_rate"] == (round(row["placed"] / eligible * 100, 1) if eligible else 0)


def test_attendance_threshold_is_configurable(client, login, database):
    login("faculty", "Faculty@1234")
    for threshold in (50, 65, 90):
        body = client.get(f"/attendance?threshold={threshold}").get_data(as_text=True)
        flagged = database.attendance.count_documents({"attendance_percentage": {"$lt": threshold}})
        assert f"Records below {threshold}%" in body
        assert f"{flagged:,} records below {threshold}%" in body
    assert app_module.parse_threshold("abc") == app_module.app.config["ATTENDANCE_THRESHOLD"]
    assert app_module.parse_threshold("500") == 100.0


def test_students_pagination_and_search(client, login, database):
    login("admin", "Admin@1234")
    page1 = client.get("/students").get_data(as_text=True)
    assert "Page 1 / 5" in page1  # 120 students, 25 per page
    assert "Page 5 / 5" in client.get("/students?page=99").get_data(as_text=True)
    first = database.students.find_one()
    assert first["student_id"] in client.get(f"/students?q={first['student_id']}").get_data(as_text=True)


# ---------------------------------------------------------------- CSV import
def _import(client, dataset, csv_text, filename="data.csv"):
    token = csrf_from(client, "/data-tools")
    return client.post("/data-tools", data={
        "dataset": dataset, "_csrf": token, "csv_file": (io.BytesIO(csv_text.encode()), filename),
    }, content_type="multipart/form-data", follow_redirects=True)


def test_import_upserts_without_duplicates(client, login, database):
    login("admin", "Admin@1234")
    row = "STU1,Test Student,Computer Engineering,2024,5,8.1,true,true\n"
    header = "student_id,name,department,batch,semester,cgpa,placement_eligible,active\n"
    assert "1 inserted" in _import(client, "students", header + row).get_data(as_text=True)
    assert "0 inserted, 1 updated" in _import(client, "students", header + row.replace("8.1", "8.5")).get_data(as_text=True)
    assert database.students.count_documents({"student_id": "STU1"}) == 1
    assert database.students.find_one({"student_id": "STU1"})["cgpa"] == 8.5


def test_import_derives_percentages_and_rejects_bad_rows(client, login, database):
    login("admin", "Admin@1234")
    header = "student_id,department,subject,academic_year,classes_held,classes_attended,attendance_percentage\n"
    _import(client, "attendance", header + "STU2,Civil,Data Structures,2024-2025,40,30,99\n")
    assert database.attendance.find_one({"student_id": "STU2"})["attendance_percentage"] == 75.0
    bad = _import(client, "attendance", header + "STU3,Civil,Data Structures,2024-2025,40,50,50\n").get_data(as_text=True)
    assert "Import failed" in bad and "Row 2" in bad
    assert database.attendance.count_documents({"student_id": "STU3"}) == 0


def test_import_rejects_wrong_extension_and_missing_columns(client, login):
    login("admin", "Admin@1234")
    assert "Please select a CSV file" in _import(client, "students", "x", "data.txt").get_data(as_text=True)
    assert "Missing required columns" in _import(client, "students", "student_id\nA1\n").get_data(as_text=True)


def test_import_requires_csrf_and_admin(client, login):
    login("faculty", "Faculty@1234")
    assert client.get("/data-tools").status_code == 302
    login_admin = client.post("/data-tools", data={"dataset": "students"})
    assert login_admin.status_code in (302, 400)
