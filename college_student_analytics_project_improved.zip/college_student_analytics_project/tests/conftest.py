"""Test fixtures: run the Flask app against an in-memory MongoDB (mongomock)."""
import os
import sys

import mongomock
import pymongo
import pytest
from werkzeug.security import generate_password_hash

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

# Compatibility shim: newer PyMongo passes a "sort" argument that older mongomock builds do not accept.
import mongomock.collection as _mc  # noqa: E402

_orig_add_update = _mc.BulkOperationBuilder.add_update


def _add_update(self, selector, doc, *args, sort=None, **kwargs):
    return _orig_add_update(self, selector, doc, *args, **kwargs)


_mc.BulkOperationBuilder.add_update = _add_update

_SHARED_CLIENT = mongomock.MongoClient()
pymongo.MongoClient = lambda *args, **kwargs: _SHARED_CLIENT  # must happen before "import app"

import app as app_module  # noqa: E402
import seed_data  # noqa: E402

USERS = [
    ("admin", "Admin@1234", "admin"),
    ("faculty", "Faculty@1234", "faculty"),
    ("placement", "Placement@1234", "placement"),
]


@pytest.fixture()
def database():
    db = app_module.db
    for name in db.list_collection_names():
        db.drop_collection(name)
    students, attendance, exams, placements = seed_data.generate_dataset(120)
    db.students.insert_many(students)
    db.attendance.insert_many(attendance)
    db.examinations.insert_many(exams)
    db.placements.insert_many(placements)
    db.users.insert_many([
        {"username": u, "password_hash": generate_password_hash(p), "role": r, "display_name": u.title(), "active": True}
        for u, p, r in USERS
    ])
    app_module._failed_logins.clear()
    return db


@pytest.fixture()
def client(database):
    app_module.app.config["TESTING"] = True
    return app_module.app.test_client()


def csrf_from(client, path="/login"):
    client.get(path)
    with client.session_transaction() as sess:
        return sess["_csrf"]


@pytest.fixture()
def login(client):
    def _login(username, password):
        token = csrf_from(client)
        return client.post("/login", data={"username": username, "password": password, "_csrf": token})
    return _login
