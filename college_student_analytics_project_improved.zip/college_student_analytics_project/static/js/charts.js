(function () {
  const dbStatus = document.getElementById("db-status");
  if (dbStatus && window.fetch) {
    fetch("/health").then((r) => r.json()).then((d) => {
      dbStatus.textContent = d.mongodb === "connected" ? "MongoDB connected" : "MongoDB disconnected";
      if (d.mongodb !== "connected") document.getElementById("db-dot").classList.add("is-down");
    }).catch(() => { dbStatus.textContent = "Status unavailable"; });
  }
  if (typeof Chart === "undefined") return;
  Chart.defaults.font.family = "Inter, Segoe UI, Arial, sans-serif";
  Chart.defaults.color = "#7d879c";
  Chart.defaults.plugins.legend.labels.usePointStyle = true;
  Chart.defaults.plugins.legend.labels.boxWidth = 8;
  const palette = ["#5b62e8", "#1da99a", "#f1b84b", "#e86d8c", "#6b9ded", "#8c72d9", "#55b9c5", "#ee9369"];
  const gridColor = "rgba(126, 139, 165, .14)";

  function barChart(id, payload, label, horizontal = false) {
    const el = document.getElementById(id);
    if (!el || !payload) return;
    new Chart(el, {
      type: "bar",
      data: { labels: payload.labels || [], datasets: [{ label, data: payload.values || [], backgroundColor: (payload.labels || []).map((_, i) => palette[i % palette.length]), borderRadius: 6, maxBarThickness: horizontal ? 24 : 38 }] },
      options: {
        responsive: true, maintainAspectRatio: false, indexAxis: horizontal ? "y" : "x",
        plugins: { legend: { display: false }, tooltip: { backgroundColor: "#202943", padding: 11, displayColors: false } },
        scales: {
          x: { grid: { display: horizontal, color: gridColor }, border: { display: false }, ticks: { maxRotation: horizontal ? 0 : 35, minRotation: 0 } },
          y: { beginAtZero: true, grid: { color: gridColor }, border: { display: false }, ticks: { precision: 0 } }
        }
      }
    });
  }

  function doughnutChart(id, payload) {
    const el = document.getElementById(id);
    if (!el || !payload) return;
    new Chart(el, {
      type: "doughnut",
      data: { labels: payload.labels || [], datasets: [{ data: payload.values || [], backgroundColor: palette.slice(0, (payload.labels || []).length), borderWidth: 0, hoverOffset: 5 }] },
      options: { responsive: true, maintainAspectRatio: false, cutout: "68%", plugins: { legend: { position: "bottom", labels: { padding: 16 } }, tooltip: { backgroundColor: "#202943", padding: 11 } } }
    });
  }

  if (window.dashboardCharts) {
    barChart("departmentScoreChart", window.dashboardCharts.department, "Average score");
    barChart("placementRateChart", window.dashboardCharts.placement, "Placement rate");
    doughnutChart("placementStatusChart", window.dashboardCharts.status);
  }
  if (window.academicCharts) {
    barChart("academicScoreChart", window.academicCharts.score, "Average score");
    barChart("subjectPassChart", window.academicCharts.pass, "Pass rate", true);
  }
  if (window.attendanceChartData) barChart("attendanceChart", window.attendanceChartData, "Attendance", true);
  if (window.placementCharts) {
    barChart("deptPlacementChart", window.placementCharts.dept, "Placement rate");
    doughnutChart("placementPipelineChart", window.placementCharts.status);
  }

  const datasetSelect = document.getElementById("dataset");
  const fieldHint = document.getElementById("field-hint");
  if (datasetSelect && fieldHint && window.datasetFieldHints) {
    const updateHint = () => {
      const fields = window.datasetFieldHints[datasetSelect.value];
      fieldHint.textContent = fields ? fields.join(", ") : "Choose a dataset to view its required column names.";
    };
    datasetSelect.addEventListener("change", updateHint);
    updateHint();
  }
})();
